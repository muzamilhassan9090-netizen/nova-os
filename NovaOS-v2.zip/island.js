/* NovaOS Island logic */
(() => {
const $=id=>document.getElementById(id);
const isl=$('island');if(!isl)return;
const fmt=s=>{s=Math.max(0,Math.round(s||0));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')};
const store={get:k=>{try{return localStorage.getItem(k)}catch(e){return null}},set:(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}}};
const dot=(id,on)=>$(id).classList.toggle('on',!!on);

/* ---- Position (left/center/right) + on/off, synced with Settings panel ---- */
const POS=['center','left','right'];
let pos=POS.includes(store.get('nova.island.pos'))?store.get('nova.island.pos'):'center';
let on=store.get('nova.island.on')!=='0';
function applyPrefs(){
 isl.dataset.pos=pos;isl.hidden=!on;
 document.querySelectorAll('[data-ipos]').forEach(b=>b.classList.toggle('selected',b.dataset.ipos===pos));
 const sw=$('islandOn');if(sw)sw.checked=on}
document.querySelectorAll('[data-ipos]').forEach(b=>b.addEventListener('click',()=>{pos=b.dataset.ipos;store.set('nova.island.pos',pos);applyPrefs()}));
if($('islandOn'))$('islandOn').addEventListener('change',e=>{on=e.target.checked;store.set('nova.island.on',on?'1':'0');applyPrefs()});
$('posBtn').onclick=()=>{pos=POS[(POS.indexOf(pos)+1)%3];store.set('nova.island.pos',pos);applyPrefs()};
applyPrefs();

/* ---- Music (local files) ---- */
const audio=new Audio();
$('mOpen').onclick=()=>$('mFile').click();
$('mFile').onchange=e=>{const f=e.target.files[0];if(!f)return;
 audio.src=URL.createObjectURL(f);const name=f.name.replace(/\.[^.]+$/,'');
 $('mTitle').textContent=name;$('mSub').textContent='NovaOS Player';audio.play();
 if('mediaSession' in navigator)navigator.mediaSession.metadata=new MediaMetadata({title:name,artist:'NovaOS Player'})};
$('mPlay').onclick=()=>{if(!audio.src)return $('mFile').click();audio.paused?audio.play():audio.pause()};
audio.onplay=()=>{$('mPlay').textContent='❚❚';dot('dMusic',1)};
audio.onpause=()=>{$('mPlay').textContent='▶';dot('dMusic',0)};
audio.onended=audio.onpause;
audio.onloadedmetadata=()=>$('mLen').textContent=fmt(audio.duration);
audio.ontimeupdate=()=>{$('mCur').textContent=fmt(audio.currentTime);if(audio.duration)$('mSeek').value=audio.currentTime/audio.duration*100};
$('mSeek').oninput=e=>{if(audio.duration)audio.currentTime=e.target.value/100*audio.duration};

/* ---- Voice recorder ---- */
let rec,chunks=[],rTimer,rStart;
$('rBtn').onclick=async()=>{
 if(rec&&rec.state==='recording')return rec.stop();
 try{const st=await navigator.mediaDevices.getUserMedia({audio:true});
  rec=new MediaRecorder(st);chunks=[];rec.ondataavailable=e=>chunks.push(e.data);
  rec.onstop=()=>{st.getTracks().forEach(t=>t.stop());clearInterval(rTimer);
   const url=URL.createObjectURL(new Blob(chunks,{type:rec.mimeType}));
   $('rBtn').classList.remove('on');$('rBtn').textContent='●';dot('dRec',0);
   $('rTxt').textContent='Recorder';$('rSub').innerHTML='<a href="'+url+'" download="nova-recording.webm" style="color:#19e3ff">Save recording</a>'};
  rec.start();rStart=Date.now();$('rBtn').classList.add('on');$('rBtn').textContent='■';dot('dRec',1);
  rTimer=setInterval(()=>{$('rTxt').textContent='Recording '+fmt((Date.now()-rStart)/1000)},500);
  $('rSub').textContent='Tap ■ to stop';
 }catch(e){$('rSub').textContent='Microphone permission needed'}};

/* ---- Timer ---- */
let tEnd=0,tInt;
function beep(){try{const c=new AudioContext();[0,.25,.5].forEach(t=>{const o=c.createOscillator(),g=c.createGain();
 o.frequency.value=880;o.connect(g);g.connect(c.destination);g.gain.setValueAtTime(.2,c.currentTime+t);o.start(c.currentTime+t);o.stop(c.currentTime+t+.15)})}catch(e){}}
function stopTimer(done){clearInterval(tInt);tEnd=0;$('tBtn').classList.remove('on');$('tBtn').textContent='▶';
 dot('dTimer',0);$('tTxt').textContent=done?'Time is up':'Timer';
 if(done){beep();isl.classList.add('pin');setTimeout(()=>isl.classList.remove('pin'),4000)}}
$('tBtn').onclick=()=>{
 if(tEnd)return stopTimer(false);
 const m=Math.max(1,parseInt($('tMin').value)||1);tEnd=Date.now()+m*60000;
 $('tBtn').classList.add('on');$('tBtn').textContent='■';dot('dTimer',1);
 tInt=setInterval(()=>{const left=(tEnd-Date.now())/1000;if(left<=0)return stopTimer(true);$('tTxt').textContent=fmt(left)},250)};

/* ---- Bluetooth (Chrome / Edge) ---- */
const devs=new Map();
const icon=n=>{n=(n||'').toLowerCase();
 if(/bud|pod|airdot|earphone|tws|ear|head|wh-|bose/.test(n))return'🎧';
 if(/speaker|jbl|boom|soundcore|sound|bar/.test(n))return'🔊';
 if(/phone|galaxy|iphone|pixel|redmi|oppo|vivo|infinix|tecno/.test(n))return'📱';
 if(/watch|band/.test(n))return'⌚';return'🔵'};
function renderBt(){
 const list=[...devs.values()].filter(d=>d.dev.gatt&&d.dev.gatt.connected);
 dot('dBt',list.length);
 $('bSub').textContent=list.length?list.length+' device'+(list.length>1?'s':'')+' connected':'No devices connected';
 $('bList').innerHTML=list.map(d=>`<li><span class="ic">${icon(d.dev.name)}</span><span class="n">${(d.dev.name||'Unknown device').replace(/[<>&]/g,'')}</span>`+
  (d.bat!=null?`<span class="bat ${d.bat<20?'low':''}">${d.bat}%</span>`:'<span class="bat" style="color:#9aa4b8">–</span>')+'</li>').join('')}
$('bAdd').onclick=async()=>{
 if(!navigator.bluetooth){$('bSub').textContent='Use Chrome or Edge for Bluetooth';return}
 try{const dev=await navigator.bluetooth.requestDevice({acceptAllDevices:true,optionalServices:['battery_service']});
  const r={dev,bat:null};devs.set(dev.id,r);
  dev.addEventListener('gattserverdisconnected',renderBt);
  const srv=await dev.gatt.connect();renderBt();
  try{const s=await srv.getPrimaryService('battery_service');const ch=await s.getCharacteristic('battery_level');
   r.bat=(await ch.readValue()).getUint8(0);
   ch.addEventListener('characteristicvaluechanged',e=>{r.bat=e.target.value.getUint8(0);renderBt()});
   await ch.startNotifications()}catch(e){}
  renderBt()}catch(e){}};

/* ---- Call card hook ---- */
window.NovaIsland={call(name){$('cCall').hidden=!name;$('callSub').textContent=name?'On call with '+name:'';isl.classList.toggle('pin',!!name)}};
})();
