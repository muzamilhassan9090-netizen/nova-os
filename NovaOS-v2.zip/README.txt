# NovaOS Lockscreen Studio

## Upload to InfinityFree
1. Extract this ZIP on your computer.
2. Open your InfinityFree account > File Manager.
3. Open `htdocs`.
4. Upload **all files** from this folder directly into `htdocs` (not the containing folder).
5. Make sure your site uses HTTPS/SSL. PWA installation and offline service workers require HTTPS (localhost also works for testing).

## Install in Chrome
1. Open your hosted website in Chrome.
2. Use the install icon in the address bar, or Chrome menu > Cast, save and share > Install page as app (wording may vary).
3. Launch NovaOS from your desktop/start menu.

## Included
- Clock positions: Top, Center, Bottom, Left, Right
- Thin, Bold and Rounded clock styles
- Preset and custom clock colors
- Wallpaper blur
- Upload your own wallpaper (up to 2 MB)
- Show/hide date
- Full-screen clock view (Esc exits)
- Local settings save and basic offline cache

## Important limitation
This is an installable web app (PWA), not a bootable operating system and not a replacement for the actual Windows/Linux sign-in lockscreen. It runs after you open it from Chrome or its installed app shortcut. Browser security prevents a website from changing the computer's real OS lockscreen.

## v2 — NovaOS Island
- New files: island.css, island.js (upload them together with index.html and sw.js).
- Thin line at the top of the screen; hover to open: music player, voice recorder, timer, Bluetooth devices (with battery if the device reports it).
- Position (Left / Center / Right) and on/off are in Settings > "Island (top popup)".
- Bluetooth works in Chrome/Edge only. Spotify/WhatsApp status cannot be read by a web app (needs a desktop app).
