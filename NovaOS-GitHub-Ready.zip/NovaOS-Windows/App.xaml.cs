using System.Windows;
namespace NovaOS;
public partial class App : Application { }