# NovaOS website download flow

The website can remain on InfinityFree:
1. Add a download button that points to the published `NovaOS.exe` or a ZIP containing the publish folder.
2. Build the desktop app on a Windows machine with the .NET 8 SDK using `BUILD-WINDOWS.ps1`.
3. Upload the published files to the website's `htdocs/downloads/` directory using FTP/File Manager.
4. Link users to `https://your-domain.example/downloads/NovaOS.exe` if using single-file publish.

A real signed installer (MSIX or a code-signed setup EXE) is preferable for public distribution. This starter project publishes a self-contained EXE, but it is not yet a signed installer. Do not tell users that the website's PWA install prompt installs a native Windows app; the download button must download the Windows build.
