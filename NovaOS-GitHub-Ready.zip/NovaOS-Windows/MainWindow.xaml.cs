using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using Windows.Media.Control;
using Windows.Devices.Enumeration;

namespace NovaOS;

public partial class MainWindow : Window
{
    private GlobalSystemMediaTransportControlsSessionManager? _mediaManager;
    private GlobalSystemMediaTransportControlsSession? _currentSession;
    private readonly DispatcherTimer _refreshTimer = new() { Interval = TimeSpan.FromSeconds(2) };
    private bool _isExpanded;
    private string _position = "Center";

    public MainWindow()
    {
        InitializeComponent();
        Loaded += MainWindow_Loaded;
        _refreshTimer.Tick += async (_, _) => await RefreshAllAsync();
        ContextMenu = BuildContextMenu();
        StateChanged += (_, _) => { if (WindowState == WindowState.Minimized) WindowState = WindowState.Normal; };
    }

    private System.Windows.Controls.ContextMenu BuildContextMenu()
    {
        var menu = new System.Windows.Controls.ContextMenu();
        foreach (var pos in new[] { "Left", "Center", "Right" })
        {
            var item = new System.Windows.Controls.MenuItem { Header = $"Align top: {pos}" };
            item.Click += (_, _) => SetPosition(pos);
            menu.Items.Add(item);
        }
        menu.Items.Add(new System.Windows.Controls.Separator());
        var exit = new System.Windows.Controls.MenuItem { Header = "Exit NovaOS" };
        exit.Click += (_, _) => System.Windows.Application.Current.Shutdown();
        menu.Items.Add(exit);
        return menu;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        SetPosition(_position);
        try
        {
            _mediaManager = await GlobalSystemMediaTransportControlsSessionManager.RequestAsync();
            _mediaManager.CurrentSessionChanged += async (_, _) => await Dispatcher.InvokeAsync(async () => await RefreshMediaAsync());
            _mediaManager.SessionsChanged += async (_, _) => await Dispatcher.InvokeAsync(async () => await RefreshMediaAsync());
        }
        catch { /* Media control can be unavailable on some Windows configurations. */ }
        await RefreshAllAsync();
        _refreshTimer.Start();
    }

    private void SetPosition(string position)
    {
        _position = position;
        var work = SystemParameters.WorkArea;
        Left = position switch
        {
            "Left" => work.Left + 18,
            "Right" => work.Right - Width - 18,
            _ => work.Left + (work.Width - Width) / 2
        };
        Top = 0;
    }

    private void Window_MouseEnter(object sender, MouseEventArgs e) => Expand();
    private void Window_MouseLeave(object sender, MouseEventArgs e)
    {
        if (ContextMenu?.IsOpen == true) return;
        Collapse();
    }
    private void ClosePanel_Click(object sender, RoutedEventArgs e) => Collapse();

    private void Expand()
    {
        if (_isExpanded) return;
        _isExpanded = true;
        CollapsedLine.Visibility = Visibility.Collapsed;
        Panel.Visibility = Visibility.Visible;
        BeginAnimation(HeightProperty, new DoubleAnimation(12, 230, TimeSpan.FromMilliseconds(230)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
        Panel.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(180)));
    }

    private void Collapse()
    {
        if (!_isExpanded) return;
        _isExpanded = false;
        Panel.BeginAnimation(OpacityProperty, new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(120)));
        var animation = new DoubleAnimation(230, 12, TimeSpan.FromMilliseconds(180)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn } };
        animation.Completed += (_, _) => { if (!_isExpanded) { Panel.Visibility = Visibility.Collapsed; CollapsedLine.Visibility = Visibility.Visible; } };
        BeginAnimation(HeightProperty, animation);
    }

    private async Task RefreshAllAsync()
    {
        await RefreshMediaAsync();
        await RefreshBluetoothAsync();
    }

    private async Task RefreshMediaAsync()
    {
        try
        {
            if (_mediaManager is null) return;
            var sessions = _mediaManager.GetSessions();
            _currentSession = _mediaManager.GetCurrentSession();
            if (_currentSession is null)
            {
                MediaCard.Visibility = Visibility.Collapsed;
                UpdateEmptyState();
                return;
            }

            var properties = await _currentSession.TryGetMediaPropertiesAsync();
            var playback = _currentSession.GetPlaybackInfo();
            var title = string.IsNullOrWhiteSpace(properties.Title) ? "Untitled media" : properties.Title;
            var artist = string.IsNullOrWhiteSpace(properties.Artist) ? "Unknown artist" : properties.Artist;
            TrackTitle.Text = title;
            TrackArtist.Text = artist;
            TrackSource.Text = _currentSession.SourceAppUserModelId ?? "Windows media session";
            PlayPauseButton.Content = playback?.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing ? "Ⅱ" : "▶";
            MediaCard.Visibility = Visibility.Visible;
        }
        catch
        {
            MediaCard.Visibility = Visibility.Collapsed;
        }
        UpdateEmptyState();
    }

    private async Task RefreshBluetoothAsync()
    {
        try
        {
            const string classic = "{e0cbf06c-cd8b-4647-bb8a-263b43f0f974}";
            const string ble = "{bb7bb05e-5972-42b5-94fc-76eaa7084d49}";
            var selector = $"(System.Devices.Aep.IsConnected:=System.StructuredQueryType.Boolean#True) AND ((System.Devices.Aep.ProtocolId:={classic}) OR (System.Devices.Aep.ProtocolId:={ble}))";
            string[] props = { "System.Devices.Aep.ProtocolId", "System.Devices.Aep.IsConnected", "System.Devices.Aep.ContainerId", "System.Devices.Aep.ModelName" };
            var found = await DeviceInformation.FindAllAsync(selector, props, DeviceInformationKind.AssociationEndpoint);
            var devices = found.Where(d => d.Properties.TryGetValue("System.Devices.Aep.IsConnected", out var connected) && connected is bool b && b)
                               .GroupBy(d => d.Properties.TryGetValue("System.Devices.Aep.ContainerId", out var id) ? id?.ToString() ?? d.Id : d.Id)
                               .Select(g => g.First()).ToList();
            var names = devices.Select(d => string.IsNullOrWhiteSpace(d.Name) ? "Bluetooth device" : d.Name).Distinct().ToList();
            BluetoothNames.Text = names.Count == 0 ? "No connected Bluetooth devices" : string.Join(" · ", names.Take(3));
            BluetoothCount.Text = $"{names.Count} connected device{(names.Count == 1 ? "" : "s")}";
            BluetoothGlyph.Text = names.Any(n => n.Contains("bud", StringComparison.OrdinalIgnoreCase) || n.Contains("ear", StringComparison.OrdinalIgnoreCase) || n.Contains("airpod", StringComparison.OrdinalIgnoreCase)) ? "🎧" : "ᛒ";
            BluetoothCard.Visibility = names.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
        }
        catch
        {
            BluetoothCard.Visibility = Visibility.Collapsed;
        }
        UpdateEmptyState();
    }

    private void UpdateEmptyState()
    {
        EmptyText.Visibility = MediaCard.Visibility == Visibility.Visible || BluetoothCard.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
    }

    private async void PlayPause_Click(object sender, RoutedEventArgs e)
    {
        if (_currentSession is not null) await _currentSession.TryTogglePlayPauseAsync();
        await RefreshMediaAsync();
    }
    private async void Previous_Click(object sender, RoutedEventArgs e)
    {
        if (_currentSession is not null) await _currentSession.TrySkipPreviousAsync();
        await RefreshMediaAsync();
    }
    private async void Next_Click(object sender, RoutedEventArgs e)
    {
        if (_currentSession is not null) await _currentSession.TrySkipNextAsync();
        await RefreshMediaAsync();
    }
}