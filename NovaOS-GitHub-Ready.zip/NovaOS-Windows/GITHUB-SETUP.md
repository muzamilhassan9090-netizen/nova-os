# Publish NovaOS with GitHub

## 1. Create the repository
1. On GitHub, create a new **public** repository named `NovaOS`.
2. Extract this ZIP and upload the **contents of this folder** to the repository root (the `.github` folder must be included).
3. Commit to the `main` branch.

## 2. Turn on GitHub Pages
1. Open repository **Settings → Pages**.
2. Under **Build and deployment → Source**, choose **GitHub Actions**.
3. The `Deploy NovaOS website to GitHub Pages` workflow will publish the site from `docs/`.

## 3. Set the correct repository links
In `docs/index.html`, replace both occurrences of `OWNER/REPOSITORY` with your GitHub username and repository name. Example: `muzammil/NovaOS`.

## 4. Build the Windows app
The `Build NovaOS for Windows` workflow runs on pushes and pull requests. It produces a `NovaOS-Windows-x64` artifact that can be downloaded from the workflow run.

To publish a public download through **GitHub Releases**, create and push a version tag after reviewing/testing the build:

```bash
git tag v0.1.0
git push origin v0.1.0
```

The workflow builds the app and attaches `NovaOS.exe` to the GitHub Release. The website's Download button points to the latest release asset.

## Important
- The current ZIP contains source code and GitHub automation, not a prebuilt or code-signed installer.
- A Windows build and real-device test are still required. GitHub Actions compilation alone does not prove all integrations work on every PC.
- This is a Windows desktop companion/overlay app, not a bootable replacement for Windows.
- The current build is a portable single-file EXE, not an MSI installer. SmartScreen may warn until the app is signed and has reputation.
- Before publishing a public release, inspect the source and test the artifact on Windows 10/11.
