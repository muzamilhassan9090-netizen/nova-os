# NovaOS — Windows Native Top Activity Pill

NovaOS is a native Windows desktop companion overlay. It is not a browser-only PWA and it is not a bootable operating system.

## Real Windows integrations
- Reads the active Windows media session (title, artist, source app and playback state) when the media app exposes a System Media Transport Controls session.
- Sends play/pause/next/previous commands to that session.
- Enumerates connected Bluetooth endpoints reported by Windows.
- Uses a transparent, always-on-top WPF window that expands on hover.

## Honest limitations
- There is no universal public Windows API for unrelated apps to inspect every WhatsApp/Teams/phone call state.
- A normal third-party app cannot universally detect another app's global screen recording state.
- Bluetooth names do not guarantee exact device-type classification.
- Media support depends on the source app publishing a Windows media session.
- A NovaOS timer is not implemented in this version.

## Build locally
Requirements: Windows 10/11 and .NET 8 SDK.

```powershell
dotnet restore
dotnet build -c Release
dotnet run
```

Publish a self-contained x64 executable:

```powershell
dotnet publish NovaOS.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o ./publish
```

## GitHub website and CI
See [GITHUB-SETUP.md](GITHUB-SETUP.md). The repository includes GitHub Actions workflows to build the Windows app and deploy the `docs/` website to GitHub Pages.

## Security and privacy
The app runs as the current user and does not upload activity data. Windows SmartScreen may warn until the executable is code-signed and has established reputation.
